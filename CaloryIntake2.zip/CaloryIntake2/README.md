# AnimatedBarCharts

Thanks to Lets Build That App guys for putting this video tutorial on animated bar charts with in-line static data. I am learning SwiftUI and changed the code to take data from an array and loop through it for display

Installation: Open the xcode project file and run. 
