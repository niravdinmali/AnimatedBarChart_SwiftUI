//
//  ContentView.swift
//  CaloryIntake
//
//  Created by Sangeetha Bhatta on 1/21/20.
//  Copyright © 2020 Sangeetha Bhatta. All rights reserved.
//

import SwiftUI

enum DayParts: Int, CaseIterable, Hashable, Identifiable {
    case morning = 0
    case afternoon
    case evening
    
    var name: String {
        return "\(self)".capitalized
    }
    
    
    var id: DayParts {self}
}


enum Days: CaseIterable, Hashable, Identifiable {
    
    case sunday
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
    
    var shortName: String {
        return String("\(self)".prefix(2)).capitalized
    }
    var id: Days {self}
    
}



struct ContentView: View {
    
    @State var pickerSelectedItem = 0
    
    @State var data: [(dayPart: DayParts, caloriesByDay: [(day:Days, calories:Int)])] =
        [
                (
                    DayParts.morning,
                        [
                            (Days.sunday, 10),
                            (Days.monday, 20),
                            (Days.tuesday, 30),
                            (Days.wednesday, 40),
                            (Days.thursday, 50),
                            (Days.friday, 60),
                            (Days.saturday, 70)
                        ]
                ),
                (
                    DayParts.afternoon,
                        [
                            (Days.sunday, 110),
                            (Days.monday, 120),
                            (Days.tuesday, 130),
                            (Days.wednesday, 140),
                            (Days.thursday, 150),
                            (Days.friday, 60),
                            (Days.saturday, 70)
                        ]
                ),
                (
                    DayParts.evening,
                        [
                            (Days.sunday, 140),
                            (Days.monday, 120),
                            (Days.tuesday, 130),
                            (Days.wednesday, 140),
                            (Days.thursday, 75),
                            (Days.friday, 89),
                            (Days.saturday, 45)
                        ]
                )
                
        ]

    
    
    
    var body: some View {
        ZStack {
            
            Color("background").edgesIgnoringSafeArea(.all)
            
            VStack {
                
                Text("Calory Intake")
                    .foregroundColor(Color("title"))
                    .font(.system(size: 34))
                    .fontWeight(.heavy)
                
                Picker(selection: $pickerSelectedItem.animation(), label: Text("")) {
                   ForEach(DayParts.allCases) { dp in
                        Text(dp.name).tag(dp.rawValue)
                    }
                    
                    
                }.pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal, 24)
                    .animation(.default)
                
                 
              HStack (spacing: 10) {
                     ForEach(0..<self.data[pickerSelectedItem].caloriesByDay.count, id: \.self)
                     { i in
                      
                        BarView(
                            value: self.data[self.pickerSelectedItem].caloriesByDay[i].calories,
                            label: self.data[self.pickerSelectedItem].caloriesByDay[i].day.shortName
                        )
                     
                     }
                
              }.padding(.top, 24)
               .animation(.default)
                
                
            }//vs
        }//zs
        
    }
}


struct BarView:  View {
    
    var value: Int
    var label: String
    
    var body: some View {
        VStack {
            ZStack(alignment: .bottom) {
                Capsule().frame(width: 30, height: 200)
                    .foregroundColor(Color(#colorLiteral(red: 0.5922044516, green: 0.7629836202, blue: 0.2380315661, alpha: 1)))
                Capsule().frame(width: 30, height: CGFloat(value))
                    .foregroundColor(.white)
            }
            Text(label)
                .padding(.top,8)
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
